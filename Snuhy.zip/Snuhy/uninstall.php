﻿<?php
// If uninstall not called by WP, exit.
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// TODO: delete options, custom tables, transients if user opted-in.
