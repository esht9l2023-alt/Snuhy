<?php
defined('ABSPATH') || exit;

class Snuhy_Gutenberg {
  public function init(){
    add_action('enqueue_block_editor_assets', function(){
      // مستقبلاً: لوحة جانبية للاقتراحات
    });
  }
}
