<?php
defined('ABSPATH') || exit;

class Snuhy_Elementor {
  public function init(){
    // مستقبلاً: ويدجت لعرض/إدراج روابط مقترحة من داخل Elementor
  }
}
