<div class="wrap snuhy-admin">
  <h1><?php esc_html_e('Links','snuhy'); ?></h1>
  <table class="widefat striped">
    <thead><tr>
      <th><?php esc_html_e('Keyword','snuhy'); ?></th>
      <th><?php esc_html_e('Target URL','snuhy'); ?></th>
      <th><?php esc_html_e('Type','snuhy'); ?></th>
      <th><?php esc_html_e('Rel','snuhy'); ?></th>
      <th><?php esc_html_e('Enabled','snuhy'); ?></th>
    </tr></thead>
    <tbody>
      <?php global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}snuhy_links ORDER BY id DESC LIMIT 100"); ?>
      <?php if($rows): foreach($rows as $r): ?>
        <tr>
          <td><?php echo esc_html($r->keyword); ?></td>
          <td><a href="<?php echo esc_url($r->target_url); ?>" target="_blank"><?php echo esc_html($r->target_url); ?></a></td>
          <td><?php echo esc_html($r->type); ?></td>
          <td><?php echo esc_html($r->rel); ?></td>
          <td><?php echo $r->enabled ? '✓' : '—'; ?></td>
        </tr>
      <?php endforeach; else: ?>
        <tr><td colspan="5"><?php esc_html_e('No links yet. Use REST or DB to insert.','snuhy'); ?></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
