<div class="wrap snuhy-admin">
  <h1><?php esc_html_e('Setup Wizard','snuhy'); ?></h1>
  <p><?php esc_html_e('Quickly configure Snuhy defaults. (stub)','snuhy'); ?></p>
</div>
