﻿=== Snuhy – Smart Links & References ===
Contributors: snuhy
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
Tags: internal links, references, seo, ai, licensing

Snuhy تبني شبكة روابط داخلية ذكية + صندوق مراجع بأسلوب ويكيبيديا + ذكاء اصطناعي + ترخيص لكل دومين.
