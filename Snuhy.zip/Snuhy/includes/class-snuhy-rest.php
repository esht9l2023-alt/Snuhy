<?php
defined('ABSPATH') || exit;

class Snuhy_REST {
  public function init(){
    add_action('rest_api_init', function(){
      register_rest_route('snuhy/v1','/links',[
        'methods'=>'GET',
        'permission_callback'=>function(){ return current_user_can('edit_snuhy_links'); },
        'callback'=>[$this,'list_links']
      ]);
      register_rest_route('snuhy/v1','/links',[
        'methods'=>'POST',
        'permission_callback'=>function(){ return current_user_can('edit_snuhy_links'); },
        'callback'=>[$this,'create_link']
      ]);
    });
  }

  public function list_links(WP_REST_Request $r){
    global $wpdb; $t = $wpdb->prefix.'snuhy_links';
    $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY id DESC LIMIT 500", ARRAY_A);
    return rest_ensure_response($rows);
  }

  public function create_link(WP_REST_Request $r){
    if (!wp_verify_nonce($r->get_header('X-WP-Nonce'),'wp_rest')) return new WP_Error('snuhy','bad nonce', ['status'=>403]);
    $keyword = sanitize_text_field($r['keyword'] ?? '');
    $url     = esc_url_raw($r['target_url'] ?? '');
    if (!$keyword || !$url) return new WP_Error('snuhy','missing params',['status'=>400]);

    global $wpdb; $t = $wpdb->prefix.'snuhy_links';
    $wpdb->insert($t, [
      'keyword'=>$keyword,
      'target_url'=>$url,
      'type'=> (Snuhy_References::is_external($url) ? 'external':'internal'),
      'rel'=> sanitize_text_field($r['rel'] ?? ''),
      'enabled'=>1
    ]);
    return rest_ensure_response(['ok'=>1,'id'=>$wpdb->insert_id]);
  }
}
