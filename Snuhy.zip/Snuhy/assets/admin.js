(function($){
  // placeholder for future React app; REST vars available in SnuhyVars
})(jQuery);
